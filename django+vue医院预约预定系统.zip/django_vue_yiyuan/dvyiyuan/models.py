from django.db import models

# Create your models here.

# 管理表
class Guanli(models.Model):
    username = models.CharField(max_length=255)
    password = models.TextField()

# 医院
class Chushou(models.Model):
    # 姓名
    username = models.CharField(max_length=255,null=True,blank=True,unique=True)
    # 密码
    password = models.CharField(max_length=255,null=True,blank=True)
    img_url = models.CharField(max_length=255, null=True, blank=True)
    # 简介
    jianjie = models.CharField(max_length=255, default='商家', null=True, blank=True)
    shouji = models.CharField(max_length=255, default='18888888888')

# 个人
class Goumai(models.Model):
    # 姓名
    username = models.CharField(max_length=255,null=True,blank=True,unique=True)
    # 密码
    password = models.CharField(max_length=255,null=True,blank=True)
    img_url = models.CharField(max_length=255, null=True, blank=True)
    # 简介
    jianjie = models.CharField(max_length=255,default='买家',null=True,blank=True)
    shouji = models.CharField(max_length=255, default='16666666666')

# 分类
class Fenlei(models.Model):
    mingcheng = models.CharField(max_length=255)

# 地区
class Diqu(models.Model):
    mingcheng = models.CharField(max_length=255)


# 医生
class Yisheng(models.Model):
    name = models.CharField(max_length=255) # 名称
    price = models.IntegerField() # 价格
    dizhi = models.CharField(max_length=255, null=True, blank=True) # 地址
    fbsj = models.DateField(null=True,blank=True,auto_now=True)
    img_url = models.CharField(max_length=255,null=True,blank=True) # 照片

    shouji = models.CharField(max_length=255,null=True,blank=True,default='13366666666')  # 手机
    nianling = models.CharField(max_length=255,null=True,blank=True,default='20')  # 年龄
    xingbie = models.CharField(max_length=255,null=True,blank=True,default='男')  # 性别
    # keshi = models.CharField(max_length=255,null=True,blank=True,default='男')  # 科室

    jianjie = models.TextField() # 简介
    zhuangtai = models.CharField(max_length=255, null=True, blank=True, default='待上架') # 上架状态
    is_shenhe = models.CharField(max_length=255, null=True, blank=True, default='待审核') # 审核状态
    maijia = models.ForeignKey(Chushou, on_delete=models.CASCADE) # 寄样人
    fenlei = models.ForeignKey(Fenlei,on_delete=models.CASCADE) # 分类
    diqu = models.ForeignKey(Diqu,on_delete=models.CASCADE) # 地区
    collect_num = models.CharField(max_length=255, null=True, blank=True, default='30')  # 浏览量

# 订单
class Dingdan(models.Model):
    # 买家
    shui = models.ForeignKey(Goumai, on_delete=models.CASCADE)
    # 什么时间
    gmsj = models.DateField(null=True,blank=True)
    # 支付状态
    zfzt = models.CharField(max_length=255, null=True, blank=True,default='待支付')
    phone = models.CharField(max_length=255, null=True, blank=True,default='')
    addr = models.CharField(max_length=255, null=True, blank=True,default='')

# 地址
class Addr(models.Model):
    shui = models.ForeignKey(Goumai, on_delete=models.CASCADE)
    username = models.CharField(max_length=255, null=True, blank=True)
    shouji = models.CharField(max_length=255, null=True, blank=True)
    addr = models.CharField(max_length=255, null=True, blank=True)